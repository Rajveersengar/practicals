package com.example.color;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button1, button2,button3;
        final ConstraintLayout constraintLayout;

        // set button 1 with its id
        button1 = findViewById(R.id.purple_200);

        // set button 2 with its id
        button2 = findViewById(R.id.teal_200);

        // set button 2 with its id
        button3 = findViewById(R.id.purple_700);

        // set relative layout with its id
        constraintLayout = findViewById(R.id.cl);

        // onClick function for button 1
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set the color to relative layout
                constraintLayout.setBackgroundResource(R.color.black);
            }
        });

        // onClick function for button 2
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set the color to relative layout
                constraintLayout.setBackgroundResource(R.color.teal_200);
            }

        });

        // onClick function for button 3
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set the color to relative layout
                constraintLayout.setBackgroundResource(R.color.purple_700);
            }
        });
    }
}
