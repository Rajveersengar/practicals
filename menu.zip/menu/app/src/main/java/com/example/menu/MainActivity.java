
package com.example.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox apple,mango,banana,grape,orange;
    Button buy;
    TextView textview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButtonClick();
    }
    public void addListenerOnButtonClick(){
        apple=(CheckBox)findViewById(R.id.apple);
        mango=(CheckBox)findViewById(R.id.mango);
        banana=(CheckBox)findViewById(R.id.banana);
        grape=(CheckBox)findViewById(R.id.grapes);
        orange=(CheckBox)findViewById(R.id.orange);
        buy=(Button)findViewById(R.id.buy);
        textview=(TextView)findViewById(R.id.t1);



        buy.setOnClickListener(new View.OnClickListener(){

            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                int price=0;
                StringBuilder result=new StringBuilder();
                result.append("Selected Items:");
                if(apple.isChecked()){
                    result.append("\nApple 40Rs");
                    price+=40;
                }
                if(banana.isChecked()){
                    result.append("\nBanana 50Rs");
                    price+=50;
                }
                if(mango.isChecked()){

                    result.append("\nMango 60Rs");
                    price+=120;
                }
                if(grape.isChecked()){
                    result.append("\nGrapes 60Rs");
                    price+=120;
                }
                if(orange.isChecked()){
                    result.append("\nOrange 60Rs");
                    price+=120;
                }
                result.append("\nTotal: "+price+"Rs");
                textview.setText(result);
                Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();
            }

        });
    }
}